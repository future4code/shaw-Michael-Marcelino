import express, { Request, Response } from 'express'
import cors from 'cors'
import { users } from './data';

const app = express();

app.use(express.json());
app.use(cors());


app.get("/users/allUser", (req, res) => {
    res.send('retornando todos os usarios')
})


app.listen(3003, function () {
    console.log("Server is running in locahost:3003 !");
});



